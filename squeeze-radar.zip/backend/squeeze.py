import pandas as pd

def squeeze_detector(df: pd.DataFrame, L:int=20, bb:float=2.0, kc:float=1.5, vf:float=1.5) -> pd.Series:
    if df.empty or len(df) < max(26, L+5):
        return pd.Series([False]*len(df), index=df.index)

    close = df["Close"].astype(float)
    high  = df["High"].astype(float)
    low   = df["Low"].astype(float)
    vol   = df["Volume"].astype(float)

    # Basic ATR proxy (true range simplified for speed)
    hl = (high - low).abs().rolling(L, min_periods=L).mean()

    ema = close.ewm(span=L, adjust=False).mean()
    kc_hi, kc_lo = ema + kc*hl, ema - kc*hl

    sma = close.rolling(L, min_periods=L).mean()
    std = close.rolling(L, min_periods=L).std(ddof=0)
    bb_hi, bb_lo = sma + bb*std, sma - bb*std

    # Squeeze condition
    sq = (bb_lo > kc_lo) & (bb_hi < kc_hi)

    # Volume confirmation
    vma = vol.rolling(L, min_periods=L).mean()
    vconf = vol > vf * vma

    # MACD confirmation
    macd = close.ewm(span=12, adjust=False).mean() - close.ewm(span=26, adjust=False).mean()
    sig  = macd.ewm(span=9, adjust=False).mean()
    mconf = macd > sig

    return (sq & vconf & mconf).fillna(False)
