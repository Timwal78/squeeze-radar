from typing import Dict, Any
import httpx, pandas as pd

def yahoo_minute(symbol: str, interval: str="1m", rng: str="1d") -> pd.DataFrame:
    url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
    params = {"interval": interval, "range": rng}
    r = httpx.get(url, params=params, timeout=15.0)
    r.raise_for_status()
    data: Dict[str, Any] = r.json()
    q = data["chart"]["result"][0]
    ts = pd.to_datetime(q["timestamp"], unit="s")
    quote = q["indicators"]["quote"][0]
    df = pd.DataFrame({
        "Open":   quote.get("open",   []),
        "High":   quote.get("high",   []),
        "Low":    quote.get("low",    []),
        "Close":  quote.get("close",  []),
        "Volume": quote.get("volume", []),
    }, index=ts)
    df = df.dropna(subset=["Open","High","Low","Close"]).astype({"Volume":"float"}).fillna(method="ffill")
    return df
