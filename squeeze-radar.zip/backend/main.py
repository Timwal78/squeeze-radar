import os, re, json, pathlib, time
from typing import Dict, List
from fastapi import FastAPI, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from starlette.staticfiles import StaticFiles

from .squeeze import squeeze_detector
from .fetch import yahoo_minute

DATA_DIR = pathlib.Path("data")
DATA_DIR.mkdir(exist_ok=True)

def parse_tickers(env: str) -> List[str]:
    raw = env or "TSLA,AMD,GME"
    parts = [p.strip() for p in raw.split(",") if p.strip()]
    cleaned = []
    for p in parts:
        # strip any markdown-like link or odd prefix
        p = re.sub(r"\[|\]|\(.*?\)", "", p)  # remove [text] and (...)
        p = p.replace("'", "").replace('"', "")
        cleaned.append(p.strip().upper())
    return cleaned

SYMS: List[str] = parse_tickers(os.getenv("TICKERS", ""))

app = FastAPI(title="Squeeze Machine API", version="1.0.0")

# If you split frontend/ backend into separate services, you can keep CORS open.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def compute_signal(sym: str) -> bool:
    try:
        df = yahoo_minute(sym)
        if df.empty:
            return False
        sig_series = squeeze_detector(df)
        return bool(sig_series.iloc[-1])
    except Exception:
        return False

def load_all() -> Dict[str, bool]:
    fp = DATA_DIR / "signals.json"
    if fp.exists():
        try:
            return json.loads(fp.read_text())
        except Exception:
            return {}
    return {}

def save_all(d: Dict[str, bool]) -> None:
    (DATA_DIR / "signals.json").write_text(json.dumps(d, indent=2))

@app.get("/api/health")
def health():
    return {"ok": True, "symbols": SYMS, "time": int(time.time())}

@app.get("/api/symbols")
def symbols():
    return {"symbols": SYMS}

@app.post("/api/refresh")
def refresh(bg: BackgroundTasks):
    for s in SYMS:
        bg.add_task(update_symbol, s)
    return {"status": "queued", "count": len(SYMS)}

def update_symbol(sym: str):
    sig = compute_signal(sym)
    all_sigs = load_all()
    all_sigs[sym] = sig
    save_all(all_sigs)

@app.get("/api/signals")
def signals():
    return load_all()

# -------- Serve built frontend (single service blueprint) --------
# Expect files in frontend/dist after build
if pathlib.Path("frontend/dist").exists():
    app.mount("/", StaticFiles(directory="frontend/dist", html=True), name="static")
