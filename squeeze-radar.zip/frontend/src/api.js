const base = '' // same host because backend serves the frontend
export const getSignals = async () => fetch(base + '/api/signals').then(r => r.json())
export const refresh = async () => fetch(base + '/api/refresh', {method:'POST'}).then(r => r.json())
export const getSymbols = async () => fetch(base + '/api/symbols').then(r => r.json())
