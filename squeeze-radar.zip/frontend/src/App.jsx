import { useEffect, useState } from 'react'
import { getSignals, refresh, getSymbols } from './api'

export default function App(){
  const [signals, setSignals] = useState({})
  const [symbols, setSymbols] = useState([])
  const [loading, setLoading] = useState(false)
  const [last, setLast] = useState(null)

  const load = async () => {
    const [sigs, syms] = await Promise.all([getSignals(), getSymbols()])
    setSignals(sigs || {})
    setSymbols(syms?.symbols || [])
    setLast(new Date().toLocaleTimeString())
  }

  const doRefresh = async () => {
    setLoading(true)
    try {
      await refresh()
      // give the backend a moment to compute, then reload
      setTimeout(load, 1500)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
    const t = setInterval(load, 5 * 60 * 1000) // every 5 minutes
    return () => clearInterval(t)
  }, [])

  return (
    <main>
      <h1>⚡ Live Squeeze Radar</h1>
      <div className="controls">
        <button onClick={doRefresh} disabled={loading}>{loading ? 'Refreshing…' : 'Refresh now'}</button>
        <small>Last update: {last || '—'}</small>
      </div>
      <table>
        <thead>
          <tr><th>Ticker</th><th>Squeeze?</th></tr>
        </thead>
        <tbody>
          {symbols.map(sym => {
            const yes = !!signals[sym]
            return (
              <tr key={sym}>
                <td>{sym}</td>
                <td><span className={'badge ' + (yes ? 'yes' : 'no')}>{yes ? 'YES' : 'NO'}</span></td>
              </tr>
            )
          })}
        </tbody>
      </table>
      <small>Includes pre-market & after-hours (1m data). Click “Refresh now” to force a scan.</small>
    </main>
  )
}
